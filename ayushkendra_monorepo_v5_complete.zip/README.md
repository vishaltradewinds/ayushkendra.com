
# Ayushkendra Mono-Repo

This repository contains the full institutional commerce stack for Ayushkendra.

## Structure
- backend/   FastAPI services
- frontend/  Next.js web app
- migrations/ Database SQL migrations
- invoices/  Sample invoice PDFs
- docs/      Compliance & operations

## Business Model
- Aggregated Institutional Supplier
- Manufacturer-executed delivery
- 11% margin on wholesale
- Bank-only payments
