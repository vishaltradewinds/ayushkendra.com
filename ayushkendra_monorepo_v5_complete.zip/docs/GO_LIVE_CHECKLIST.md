
# Ayushkendra Production Go-Live Checklist

## Pre-Go-Live
- [ ] Domain DNS configured (www.ayushkendra.com)
- [ ] SSL enabled
- [ ] Bank account verified
- [ ] GSTIN verified
- [ ] Manufacturer MoUs signed

## Technical
- [ ] Backend deployed (FastAPI)
- [ ] Frontend deployed (Next.js)
- [ ] Database migrations applied
- [ ] Daily backups enabled

## Operations
- [ ] Admin users created
- [ ] Settlement SLA (T+7) enforced
- [ ] Invoice PDF tested
- [ ] GST reports validated

## Compliance
- [ ] PSU annexures approved
- [ ] Audit logs enabled
