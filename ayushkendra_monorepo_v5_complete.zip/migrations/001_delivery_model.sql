
ALTER TABLE orders
ADD COLUMN delivery_mode TEXT,
ADD COLUMN logistics_partner_name TEXT,
ADD COLUMN dispatch_pincode CHAR(6),
ADD COLUMN delivery_pincode CHAR(6),
ADD COLUMN distance_km NUMERIC,
ADD COLUMN delivery_type TEXT,
ADD COLUMN delivery_charges NUMERIC;
