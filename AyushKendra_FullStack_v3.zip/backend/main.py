from fastapi import FastAPI
app=FastAPI(title='AyushKendra v3')
@app.get('/')
def root(): return {'status':'v3 running'}
